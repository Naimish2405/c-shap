﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace perloop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Any Number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i=1,old=2,New=3,K=1;
            do
            {
                int j = 1;
                do
                {
                    if (K <= 3)
                    {
                        Console.Write(K + " ");
                    }
                    else
                    {
                        K = old * New;
                        if (K > n)
                        {
                            break;
                        }
                        Console.Write(K + " ");
                        old = New;
                        New = K;
                    }
                    K++;
                    j++;
                }
                while (j <= i);
                i++;
                if (K > n)
                {
                    break;
                }
                Console.WriteLine();
            }
            while (i <= n);
            Console.Read();

                        }
    }
}
